

function telegram(){
    fetch(`https://api.telegram.org/bot7748382869:AAHLM0FFS3mYcA9RGlrSe35s2D3xjUvH4cQ/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            chat_id: tg.initDataUnsafe?.user?.id,
            text: "Hello depuis la Web App !"
        })
    }).then(response => response.json())
      .then(data => console.log("Message envoyé :", data))
      .catch(error => console.error("Erreur :", error));
}

document.addEventListener('DOMContentLoaded', () => {
    // Image slider functionality
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;

    function showSlide(index) {
        slides.forEach(slide => slide.classList.remove('active'));
        slides[index].classList.add('active');
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    setInterval(nextSlide, 3000); // Change slide every 3 seconds
    // Password visibility toggle
    document.querySelectorAll('.toggle-password').forEach(icon => {
        icon.addEventListener('click', () => {
            const input = icon.previousElementSibling;
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });

    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const modal = document.getElementById('authModal');
    const closeBtn = document.querySelector('.close');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    let currentLanguage = 'en';

    // Language switching
    window.switchLanguage = (lang) => {
        currentLanguage = lang;
        document.querySelectorAll('[data-en]').forEach(element => {
            element.textContent = element.getAttribute(`data-${lang}`);
        });
    };

    // Modal handling
    const showModal = (formType) => {
        modal.style.display = 'block';
        if (formType === 'login') {
            loginForm.classList.remove('hidden');
            registerForm.classList.add('hidden');
        } else {
            loginForm.classList.add('hidden');
            registerForm.classList.remove('hidden');
        }
    };

    const closeModal = () => {
        modal.style.display = 'none';
    };

    loginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showModal('login');
    });
    
    registerBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showModal('register');
    });
    
    closeBtn.addEventListener('click', closeModal);
    
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Form submissions
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // TODO: Implement login logic
        console.log('Login submitted');
    });

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // TODO: Implement registration logic
        console.log('Registration submitted');
    });

    // Animation for subscription buttons
    document.querySelectorAll('.subscribe-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            btn.style.animation = 'pulse 0.3s ease';
            setTimeout(() => {
                btn.style.animation = '';
            }, 300);
        });
    });
});
