
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const SITE_ID = "105887867";
const API_KEY = "67050856467af0f50c323e2.86955786";
const NOTIFY_URL = "https://your-repl-url.repl.co/notify";
const RETURN_URL = "https://your-repl-url.repl.co/return";

app.post('/initiate-payment', async (req, res) => {
  try {
    const { amount, currency = "XOF", description, trans_id } = req.body;

    const paymentData = {
      apikey: API_KEY,
      site_id: SITE_ID,
      transaction_id: trans_id,
      amount: amount,
      currency: currency,
      description: description,
      notify_url: NOTIFY_URL,
      return_url: RETURN_URL,
      channels: "ALL",
      lang: "fr",
    };

    const response = await axios.post(
      'https://api-checkout.cinetpay.com/v2/payment',
      paymentData
    );

    res.json(response.data);
  } catch (error) {
    res.status(500).json({
      error: "Payment initialization failed",
      details: error.message
    });
  }
});

app.post('/notify', (req, res) => {
  // Handle payment notification from CinetPay
  console.log('Payment notification:', req.body);
  res.sendStatus(200);
});

app.get('/return', (req, res) => {
  // Handle user return after payment
  res.redirect('/');
});

const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
